<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include 'conn.php';

$input = file_get_contents("php://input");
error_log("Raw input received: " . $input);

$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["success" => false, "message" => "JSON decode error: " . json_last_error_msg()]);
    exit;
}

$userId = isset($data["id"]) ? intval($data["id"]) : 0;

// Determine if single or multiple character IDs sent
$characterIds = [];

if (isset($data["character_ids"]) && is_array($data["character_ids"])) {
    $characterIds = $data["character_ids"];
} elseif (isset($data["character_id"])) {
    $characterIds = [$data["character_id"]];
}

if ($userId <= 0 || empty($characterIds)) {
    echo json_encode(["success" => false, "message" => "Missing or invalid user ID or character IDs."]);
    exit;
}

$unlocked = [];
$skipped = [];
$alreadyUnlocked = [];

foreach ($characterIds as $characterId) {
    $characterId = intval($characterId);

    // Skip invalid or zero IDs
    if ($characterId <= 0) {
        $skipped[] = $characterId;
        continue;
    }

    // Use INSERT ... ON DUPLICATE KEY UPDATE to insert new or update existing timestamp
    $sql = "INSERT INTO unlocked_characters (user_id, character_id, unlocked_at) 
            VALUES ($userId, $characterId, NOW())
            ON DUPLICATE KEY UPDATE unlocked_at = NOW()";

    if ($conn->query($sql) === TRUE) {
        // Check if row existed before or not
        $affectedRows = $conn->affected_rows;
        if ($affectedRows == 1) {
            // New insert
            $unlocked[] = $characterId;
        } elseif ($affectedRows == 2) {
            // Row updated (already unlocked before, timestamp updated)
            $alreadyUnlocked[] = $characterId;
        } else {
            // Unexpected affected_rows count (0 or other)
            error_log("Unexpected affected_rows: $affectedRows for user_id=$userId, character_id=$characterId");
        }
    } else {
        error_log("DB insert/update failed for character_id=$characterId: " . $conn->error);
    }
}

$conn->close();

echo json_encode([
    "success" => true,
    "message" => "Character unlock process complete.",
    "unlocked" => $unlocked,
    "already_unlocked" => $alreadyUnlocked,
    "skipped" => $skipped
]);

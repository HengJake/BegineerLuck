<?php
    // Allow requests from any origin
    header("Access-Control-Allow-Origin: *");

    // Handle preflight OPTIONS request
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        header("Access-Control-Allow-Methods: POST, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type");
        exit(0); // respond with 200 OK
    }

    include 'conn.php';

    // Read the incoming JSON input
    $input = json_decode(file_get_contents('php://input'), true);

    // Log the input data for debugging
    error_log("Received input: " . print_r($input, true));

    $username = trim($input['username'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';

    $errors = [];

    // === Validation ===
    if (empty($username) || empty($email) || empty($password)) {
        $errors[] = "Username, email, and password are required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (strlen($username) < 4 || strlen($password) < 6) {
        $errors[] = "Username must be ≥ 4 characters and password ≥ 6 characters.";
    }

    // === Uniqueness Checks ===
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $errors[] = "Username already taken.";
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $errors[] = "Email is already registered.";
    }

    // If there are validation errors, return them
    if (!empty($errors)) {
        error_log("Validation errors: " . implode(" ", $errors)); // Log errors
        echo json_encode(["success" => false, "message" => implode(" ", $errors)]);
        exit();
    }

    // === Insert User ===
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $created_at = date('Y-m-d H:i:s');

    $walletAddress = trim($input['walletAddress'] ?? '');

    $sql = "INSERT INTO users (username, email, password_hash, created_at, wallet_address) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $username, $email, $hashed_password, $created_at, $walletAddress);


    if ($stmt->execute()) {
        // Log success and return a response
        error_log("User created successfully with username: $username");
        echo json_encode([
            "success" => true,
            "message" => "Signup successful.",
            "data" => [
                "user_id" => $conn->insert_id,
                "username" => $username,
                "created_at" => $created_at
            ]
        ]);
    } else {
        // Log the failure and return an error
        error_log("Failed to insert user: " . $stmt->error);
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Signup failed. Please try again."]);
    }
?>

<?php
    // CORS headers
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: Content-Type");
    header("Access-Control-Allow-Methods: POST, OPTIONS");

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        // Respond to preflight request
        http_response_code(200);
        exit();
    }
    
    header("Content-Type: application/json");
    include 'conn.php';

    // Get input JSON
    $input = json_decode(file_get_contents("php://input"), true);

    if (!$input || !is_array($input)) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Invalid input data"
        ]);
        exit;
    }

    if (!isset($input['username']) || !isset($input['password'])) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Missing username or password."
        ]);
        exit;
    }

    $username = $input['username'];
    $password = $input['password'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, username, password_hash FROM users WHERE username = ? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password_hash'])) {
            echo json_encode([
                "success" => true,
                "message" => "Login successful",
                "username" => $user['username'],
                "id" => $user['id']
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                "success" => false,
                "message" => "Invalid credentials"
            ]);
        }
    } else {
        http_response_code(404);
        echo json_encode([
            "success" => false,
            "message" => "User not found"
        ]);
    }
?>

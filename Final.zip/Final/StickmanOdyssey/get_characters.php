<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include 'conn.php';

// Get user_id from GET parameter
$userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($userId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Missing or invalid user_id parameter."
    ]);
    exit;
}

$sql = "SELECT character_id FROM unlocked_characters WHERE user_id = $userId";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode([
        "success" => false,
        "message" => "Database query failed: " . $conn->error
    ]);
    exit;
}

$unlockedCharacters = [];

while ($row = $result->fetch_assoc()) {
    $unlockedCharacters[] = intval($row['character_id']);
}

$conn->close();

echo json_encode([
    "success" => true,
    "unlocked_characters" => $unlockedCharacters
]);
